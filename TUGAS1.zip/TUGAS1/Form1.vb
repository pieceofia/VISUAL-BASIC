﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim LABEL1 = TextNama.Text
        Dim LABEL2 = TextNpm.Text
        Dim LABEL3 = TextJurusan.Text
        Dim LABEL4 = TextNT.Text
        Dim LABEL5 = TextSks.Text
        Dim LABEL6 = TextNut.Text
        Dim LABEL7 = TextNB.Text
        Dim LABEL8 = TextUa.Text
        Dim LABEL9 = TextSemester.Text
        Dim LABEL10 = TextIps.Text
        Dim LABEL11 = TextIpk.Text
        TextNB.Text = ((TextNT.Text * 0.2) + TextNut.Text * 0.3 + TextUa.Text * 0.5)
        TextIps.Text = ((TextNB.Text * 4) / 100)
        TextIpk.Text = TextIps.Text
        Dim grade As String
        If TextNB.Text >= 80 Then
            grade = "A"
            TextGrade.Text = grade

        ElseIf TextNB.Text >= 70 Then
            grade = "B"
            TextGrade.Text = grade

        ElseIf TextNB.Text >= 60 Then
            grade = "C"
            TextGrade.Text = grade

        ElseIf TextNB.Text >= 50 Then
            grade = "D"
            TextGrade.Text = grade

        ElseIf TextNB.Text < 50 Then
            grade = "E"
            TextGrade.Text = grade
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextNama.Text = ""
        TextNpm.Text = ""
        TextJurusan.Text = ""
        TextNT.Text = ""
        TextSks.Text = ""
        TextNut.Text = ""
        TextNB.Text = ""
        TextUa.Text = ""
        TextSemester.Text = ""
        TextIps.Text = ""
        TextIpk.Text = ""
        TextGrade.Text = ""
    End Sub
End Class
