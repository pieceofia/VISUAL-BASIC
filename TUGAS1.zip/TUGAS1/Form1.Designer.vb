﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextNama = New System.Windows.Forms.TextBox()
        Me.TextNpm = New System.Windows.Forms.TextBox()
        Me.TextJurusan = New System.Windows.Forms.TextBox()
        Me.TextNT = New System.Windows.Forms.TextBox()
        Me.TextSks = New System.Windows.Forms.TextBox()
        Me.TextNut = New System.Windows.Forms.TextBox()
        Me.TextNB = New System.Windows.Forms.TextBox()
        Me.TextUa = New System.Windows.Forms.TextBox()
        Me.TextSemester = New System.Windows.Forms.TextBox()
        Me.TextIps = New System.Windows.Forms.TextBox()
        Me.TextIpk = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextGrade = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(40, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 20)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "NAMA"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 61)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 20)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "NPM"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(40, 99)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 20)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "JURUSAN"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(40, 178)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "NILAI TUGAS"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(300, 172)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(41, 20)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "SKS"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(40, 211)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 20)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "NILAI UTS"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(40, 275)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(109, 20)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "NILAI BOBOT"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(40, 243)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 20)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "NILAI UAS"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(40, 135)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(152, 20)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "TOTAL SEMESTER"
        '
        'TextNama
        '
        Me.TextNama.Location = New System.Drawing.Point(216, 20)
        Me.TextNama.Name = "TextNama"
        Me.TextNama.Size = New System.Drawing.Size(100, 26)
        Me.TextNama.TabIndex = 9
        '
        'TextNpm
        '
        Me.TextNpm.Location = New System.Drawing.Point(216, 55)
        Me.TextNpm.Name = "TextNpm"
        Me.TextNpm.Size = New System.Drawing.Size(100, 26)
        Me.TextNpm.TabIndex = 10
        '
        'TextJurusan
        '
        Me.TextJurusan.Location = New System.Drawing.Point(216, 96)
        Me.TextJurusan.Name = "TextJurusan"
        Me.TextJurusan.Size = New System.Drawing.Size(100, 26)
        Me.TextJurusan.TabIndex = 11
        '
        'TextNT
        '
        Me.TextNT.Location = New System.Drawing.Point(156, 172)
        Me.TextNT.Name = "TextNT"
        Me.TextNT.Size = New System.Drawing.Size(100, 26)
        Me.TextNT.TabIndex = 12
        '
        'TextSks
        '
        Me.TextSks.Location = New System.Drawing.Point(366, 172)
        Me.TextSks.Name = "TextSks"
        Me.TextSks.Size = New System.Drawing.Size(100, 26)
        Me.TextSks.TabIndex = 13
        '
        'TextNut
        '
        Me.TextNut.Location = New System.Drawing.Point(156, 208)
        Me.TextNut.Name = "TextNut"
        Me.TextNut.Size = New System.Drawing.Size(100, 26)
        Me.TextNut.TabIndex = 14
        '
        'TextNB
        '
        Me.TextNB.Enabled = False
        Me.TextNB.Location = New System.Drawing.Point(156, 275)
        Me.TextNB.Name = "TextNB"
        Me.TextNB.ReadOnly = True
        Me.TextNB.Size = New System.Drawing.Size(100, 26)
        Me.TextNB.TabIndex = 15
        '
        'TextUa
        '
        Me.TextUa.Location = New System.Drawing.Point(156, 240)
        Me.TextUa.Name = "TextUa"
        Me.TextUa.Size = New System.Drawing.Size(100, 26)
        Me.TextUa.TabIndex = 16
        '
        'TextSemester
        '
        Me.TextSemester.Location = New System.Drawing.Point(216, 132)
        Me.TextSemester.Name = "TextSemester"
        Me.TextSemester.Size = New System.Drawing.Size(100, 26)
        Me.TextSemester.TabIndex = 17
        '
        'TextIps
        '
        Me.TextIps.Enabled = False
        Me.TextIps.Location = New System.Drawing.Point(156, 307)
        Me.TextIps.Name = "TextIps"
        Me.TextIps.ReadOnly = True
        Me.TextIps.Size = New System.Drawing.Size(100, 26)
        Me.TextIps.TabIndex = 18
        '
        'TextIpk
        '
        Me.TextIpk.Enabled = False
        Me.TextIpk.Location = New System.Drawing.Point(366, 298)
        Me.TextIpk.Name = "TextIpk"
        Me.TextIpk.ReadOnly = True
        Me.TextIpk.Size = New System.Drawing.Size(100, 26)
        Me.TextIpk.TabIndex = 19
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(96, 307)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(35, 20)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "IPS"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(307, 304)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(34, 20)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "IPK"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Mongolian Baiti", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(526, 13)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(262, 30)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "FORM PENILAIAN"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(160, 351)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 37)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "COUNT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(264, 351)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(88, 37)
        Me.Button2.TabIndex = 24
        Me.Button2.Text = "DELETE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(298, 214)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(54, 20)
        Me.Label13.TabIndex = 25
        Me.Label13.Text = "Grade"
        '
        'TextGrade
        '
        Me.TextGrade.Enabled = False
        Me.TextGrade.Location = New System.Drawing.Point(366, 211)
        Me.TextGrade.Name = "TextGrade"
        Me.TextGrade.ReadOnly = True
        Me.TextGrade.Size = New System.Drawing.Size(100, 26)
        Me.TextGrade.TabIndex = 26
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.TextGrade)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.TextIpk)
        Me.Controls.Add(Me.TextIps)
        Me.Controls.Add(Me.TextSemester)
        Me.Controls.Add(Me.TextUa)
        Me.Controls.Add(Me.TextNB)
        Me.Controls.Add(Me.TextNut)
        Me.Controls.Add(Me.TextSks)
        Me.Controls.Add(Me.TextNT)
        Me.Controls.Add(Me.TextJurusan)
        Me.Controls.Add(Me.TextNpm)
        Me.Controls.Add(Me.TextNama)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents TextNama As TextBox
    Friend WithEvents TextNpm As TextBox
    Friend WithEvents TextJurusan As TextBox
    Friend WithEvents TextNT As TextBox
    Friend WithEvents TextSks As TextBox
    Friend WithEvents TextNut As TextBox
    Friend WithEvents TextNB As TextBox
    Friend WithEvents TextUa As TextBox
    Friend WithEvents TextSemester As TextBox
    Friend WithEvents TextIps As TextBox
    Friend WithEvents TextIpk As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents TextGrade As TextBox
End Class
